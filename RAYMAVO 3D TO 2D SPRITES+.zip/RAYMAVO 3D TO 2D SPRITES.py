import bpy
import os
import math
import sys
from bpy.props import StringProperty
from bpy.types import Operator, Panel, PropertyGroup

bl_info = {
    "name": "Render Sprite Sheet",
    "blender": (2, 80, 0),
    "category": "Render",
}

class RenderSpriteSheetProperties(PropertyGroup):
    output_dir: StringProperty(
        name="Output Directory",
        description="Directory to save rendered images",
        default="",
        subtype='DIR_PATH'
    )

class RENDER_OT_sprite_sheet(Operator):
    bl_idname = "render.sprite_sheet"
    bl_label = "Render Sprite Sheet"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.render_sprite_sheet_props
        output_dir = bpy.path.abspath(props.output_dir)

        if not os.path.exists(output_dir):
            try:
                os.makedirs(output_dir)
            except Exception as e:
                self.report({'ERROR'}, f"Failed to create directory: {e}")
                return {'CANCELLED'}

        num_frames = 8
        angles = [i * (360 / num_frames) for i in range(num_frames)]

        def get_unique_filename(directory, base_name, extension):
            counter = 1
            while True:
                filename = f"{base_name}_{counter:04d}.{extension}"
                if not os.path.exists(os.path.join(directory, filename)):
                    return filename
                counter += 1

        def find_or_create_camera():
            for obj in bpy.data.objects:
                if obj.type == 'CAMERA':
                    return obj
            # Create a new camera if none exists
            bpy.ops.object.camera_add()
            return bpy.context.active_object

        def find_target_object():
            for obj in bpy.data.objects:
                if obj.type == 'MESH':
                    return obj
            raise Exception("No target object found in the scene")

        def setup_camera(camera, target_object):
            camera.rotation_euler = (-90 * math.pi / 180, 0, 0)
            bpy.context.view_layer.objects.active = camera
            bpy.context.view_layer.update()
            bpy.ops.object.select_all(action='DESELECT')
            camera.select_set(True)
            bpy.context.view_layer.objects.active = camera
            bpy.context.view_layer.update()
            bpy.context.view_layer.objects.active = camera
            bpy.ops.object.constraint_add(type='TRACK_TO')
            track_to_constraint = camera.constraints[-1]
            track_to_constraint.target = target_object
            track_to_constraint.track_axis = 'TRACK_NEGATIVE_Z'
            track_to_constraint.up_axis = 'UP_Y'
            return track_to_constraint

        def setup_render_settings(scene):
            scene.render.engine = 'CYCLES'
            scene.cycles.samples = 128
            scene.cycles.use_adaptive_sampling = True
            scene.cycles.adaptive_threshold = 0.05
            scene.cycles.use_denoising = True
            scene.cycles.denoiser = 'OPENIMAGEDENOISE'
            scene.cycles.device = 'GPU'
            scene.render.resolution_x = 512
            scene.render.resolution_y = 512
            scene.render.resolution_percentage = 100
            scene.render.film_transparent = True

        def setup_animation(camera, target_object, radius, num_frames, angles):
            scene = bpy.context.scene
            scene.frame_start = 1
            scene.frame_end = num_frames * 2
            for i, angle in enumerate(angles):
                angle_rad = math.radians(angle)
                camera.location = (
                    target_object.location.x + radius * math.cos(angle_rad),
                    target_object.location.y + radius * math.sin(angle_rad),
                    target_object.location.z
                )
                camera.keyframe_insert(data_path="location", frame=i + 1)
            for i, angle in enumerate(angles):
                angle_rad = math.radians(angle)
                camera.location = (
                    target_object.location.x + radius * math.cos(angle_rad),
                    target_object.location.y + radius * math.sin(angle_rad),
                    target_object.location.z + radius
                )
                camera.rotation_euler = (math.pi / 2, 0, angle_rad)
                camera.keyframe_insert(data_path="location", frame=num_frames + i + 1)
                camera.keyframe_insert(data_path="rotation_euler", frame=num_frames + i + 1)

        def render_frames_one_by_one(scene, output_dir, num_frames):
            def render_next_frame():
                nonlocal current_frame
                if current_frame > scene.frame_end:
                    bpy.app.timers.unregister(render_next_frame)
                    bpy.app.timers.register(create_sprite_sheet_task)
                    return
                try:
                    unique_filename = get_unique_filename(output_dir, "sprite", "png")
                    scene.render.filepath = os.path.join(output_dir, unique_filename)
                    bpy.context.scene.frame_set(current_frame)
                    bpy.ops.render.render(write_still=True)
                    current_frame += 1
                except Exception as e:
                    print(f"Error during rendering frame {current_frame}: {e}")
                    bpy.app.timers.unregister(render_next_frame)
                    return
                return 0.1

            current_frame = 1
            bpy.app.timers.register(render_next_frame)

        def create_sprite_sheet_task():
            def create_sprite_sheet():
                sprite_sheet_width = 512 * num_frames
                sprite_sheet_height = 512 * 2
                sprite_sheet = bpy.data.images.new("SpriteSheet", width=sprite_sheet_width, height=sprite_sheet_height, alpha=True)
                for i in range(num_frames):
                    image_path = os.path.join(output_dir, f"sprite_{str(i+1).zfill(4)}.png")
                    image = bpy.data.images.load(image_path)
                    x_offset = i * 512
                    for y in range(512):
                        for x in range(512):
                            index = (y * 512 + x) * 4
                            sprite_sheet.pixels[(y * sprite_sheet_width + x + x_offset) * 4 : (y * sprite_sheet_width + x + x_offset) * 4 + 4] = image.pixels[index : index + 4]
                    bpy.context.window_manager.progress_update((i + 1) / (num_frames * 2))
                    image_path = os.path.join(output_dir, f"sprite_{str(num_frames + i + 1).zfill(4)}.png")
                    image = bpy.data.images.load(image_path)
                    x_offset = i * 512
                    for y in range(512):
                        for x in range(512):
                            index = (y * 512 + x) * 4
                            sprite_sheet.pixels[((y + 512) * sprite_sheet_width + x + x_offset) * 4 : ((y + 512) * sprite_sheet_width + x + x_offset) * 4 + 4] = image.pixels[index : index + 4]
                    bpy.context.window_manager.progress_update(((num_frames + i + 1) / (num_frames * 2)))
                sprite_sheet.filepath_raw = os.path.join(output_dir, "sprite_sheet.png")
                sprite_sheet.file_format = 'PNG'
                sprite_sheet.save()
                bpy.app.timers.register(cleanup_task)
                return None

            return create_sprite_sheet

        def cleanup_task():
            def cleanup():
                camera.constraints.remove(track_to_constraint)
                camera.animation_data_clear()
                print("Script finished successfully.")
                sys.exit("Script execution completed.")
                return None

            return cleanup

        camera = find_or_create_camera()
        target_object = find_target_object()
        global track_to_constraint
        track_to_constraint = setup_camera(camera, target_object)
        setup_render_settings(bpy.context.scene)
        setup_animation(camera, target_object, 3, num_frames, angles)
        render_frames_one_by_one(bpy.context.scene, output_dir, num_frames)

        return {'FINISHED'}

class RENDER_PT_sprite_sheet(Panel):
    bl_label = "RAYMAVO 3D to 2D Sprites"
    bl_idname = "RENDER_PT_sprite_sheet"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Render'

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        props = scene.render_sprite_sheet_props

        layout.prop(props, "output_dir")
        layout.operator("render.sprite_sheet", text="Start Rendering")

def register():
    bpy.utils.register_class(RenderSpriteSheetProperties)
    bpy.utils.register_class(RENDER_OT_sprite_sheet)
    bpy.utils.register_class(RENDER_PT_sprite_sheet)
    bpy.types.Scene.render_sprite_sheet_props = bpy.props.PointerProperty(type=RenderSpriteSheetProperties)

def unregister():
    bpy.utils.unregister_class(RenderSpriteSheetProperties)
    bpy.utils.unregister_class(RENDER_OT_sprite_sheet)
    bpy.utils.unregister_class(RENDER_PT_sprite_sheet)
    del bpy.types.Scene.render_sprite_sheet_props

if __name__ == "__main__":
    register()